﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taki
{   // Json Object which is related to the one the server sends
    public class JSONObject
    {
        public int turn { get; set; }
        public string pile_color { get; set; }
        public List<Dictionary<string, string>> hand;
        public List<int> players;
        public List<string> winners;
        public Dictionary<string, string> pile;
        public int turn_dir { get; set; }
        public List<int> others;

        public JSONObject() {
            hand = new List<Dictionary<string, string>>();
            players = new List<int>();
            winners = new List<string>();
            others = new List<int>();
        }
    }
}
