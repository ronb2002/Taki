﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taki
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            GameManager.GameForm = this;
            GameManager.CreateCards();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!GameManager.gameStarted)
                GameManager.StartGame();
        }

        private static bool Contains(List<Dictionary<string, string>> hand, Dictionary<string, string> dict)
        {
            foreach (Dictionary<string, string> dict1 in hand)
            {
                if (GameManager.DictionaryToCardObject(dict1) == GameManager.DictionaryToCardObject(dict))
                    return true;
            }
            return false;
        }

        private static int CheckCurrectIndex(int turn, int i)
        {
            int realTurn = turn;
            if (turn == 1)
            {
                if (!GameManager.items[i].players.Contains(0))
                    realTurn = 0;
            }
            else if (turn == 2)
            {
                if (!GameManager.items[i].players.Contains(0) && !GameManager.items[i].players.Contains(1))
                    realTurn = 0;
                else if (!GameManager.items[i].players.Contains(0) || !GameManager.items[i].players.Contains(1))
                    realTurn = 1;
            }
            else if (turn == 3)
            {
                if (!GameManager.items[i].players.Contains(0) && !GameManager.items[i].players.Contains(1) && !GameManager.items[i].players.Contains(2))
                    realTurn = 0;
                else if (!GameManager.items[i].players.Contains(0) && !GameManager.items[i].players.Contains(1) && GameManager.items[i].players.Contains(2))
                    realTurn = 1;
                else if (!GameManager.items[i].players.Contains(0) && GameManager.items[i].players.Contains(1) && !GameManager.items[i].players.Contains(2))
                    realTurn = 1;
                else if (GameManager.items[i].players.Contains(0) && !GameManager.items[i].players.Contains(1) && !GameManager.items[i].players.Contains(2))
                    realTurn = 1;
                else if (!GameManager.items[i].players.Contains(0) || !GameManager.items[i].players.Contains(1) || !GameManager.items[i].players.Contains(2))
                    realTurn = 2;
            }
            if (GameManager.items[i].players.Count != GameManager.items[i].others.Count)
            {
                int empty = GameManager.items[i].others.IndexOf(0);
                if (realTurn >= empty)
                    realTurn += 1;
            }
            if (realTurn >= GameManager.items[i].others.Count)
                realTurn = GameManager.items[i].others.Count - 1;
            return realTurn;
        }

        private void ShowWinnerMessage(int player, int i)
        {
            if (GameManager.items[i].winners[0] != null && GameManager.items[i].winners[0] == null && !GameManager.items[i].players.Contains(GameManager.ourID))
            {
                MessageBox.Show("You Are Third");
                return;
            }
            else if(GameManager.items[i].winners[0] != null && GameManager.items[i].winners[0] != null && !GameManager.items[i].players.Contains(GameManager.ourID))
            {
                MessageBox.Show("You Are Last");
                return;
            }
            string playerStr;
            if (int.Parse(GameManager.items[i].winners[0]) - GameManager.ourID < 0)
                playerStr = "3";
            else
                playerStr = (int.Parse(GameManager.items[i].winners[0]) - GameManager.ourID).ToString();
            string winners = "First: " + playerStr + "\n";
            if (int.Parse(GameManager.items[i].winners[1]) - GameManager.ourID < 0)
                playerStr = "3";
            else
                playerStr = (int.Parse(GameManager.items[i].winners[1]) - GameManager.ourID).ToString();
            winners += "Second: " + playerStr + "\n";
            winners += "Third: " + player.ToString() + "\n";
            if (GameManager.items[i].players[0] == GameManager.items[i].turn)
            {
                if (GameManager.items[i].players[1] - GameManager.ourID < 0)
                    playerStr = "3";
                else
                    playerStr = (GameManager.items[i].players[1] - GameManager.ourID).ToString();
            }
            else
            {
                if (GameManager.items[i].players[0] - GameManager.ourID < 0)
                    playerStr = "3";
                else
                    playerStr = (GameManager.items[i].players[0] - GameManager.ourID).ToString();
            }
            winners += "Last: " + playerStr;
            MessageBox.Show(winners);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (GameManager.gameOver || !GameManager.gameStarted)
                return;
            int i = GameManager.current_turn;
            if (i != GameManager.items.Count - 1)
            {
                int player = GameManager.items[i].turn - GameManager.ourID;
                if (player < 0)
                {
                    player += 4;
                }
                label2.Text = GameManager.current_turn.ToString();
                Card pile = GameManager.DictionaryToCardObject(GameManager.items[i].pile);
                bool add;
                int turn2 = CheckCurrectIndex(GameManager.items[i].turn, i + 1);
                int turn1;
                if (GameManager.items[i + 1].others.Count < GameManager.items[i].others.Count)
                    turn1 = CheckCurrectIndex(GameManager.items[i].turn, i);
                else
                    turn1 = turn2;
                if (GameManager.items[i + 1].others[turn2] > GameManager.items[i].others[turn1])
                {
                    add = true;
                }
                else
                {
                    add = false;
                }
                Card card = GameManager.FindCard(CardColor.NoColor, CardType.Back);
                if (GameManager.items[i].turn == GameManager.ourID)
                {
                    if (add)
                    {
                        if (GameManager.items[i + 1].others[turn2] - GameManager.items[i].others[turn1] > 1)
                        {
                            for (int x = 0; x < GameManager.items[i + 1].others[turn2] - GameManager.items[i].others[turn1] - 1; x++)
                            {
                                foreach (Dictionary<string, string> dict in GameManager.items[i + 1].hand)
                                {
                                    GameManager.DictionaryToCardObject(dict);
                                    if (!Contains(GameManager.items[i].hand, dict))
                                    {
                                        card = GameManager.DictionaryToCardObject(dict);
                                        if(x != GameManager.items[i + 1].others[turn2] - GameManager.items[i].others[turn1] - 2)
                                            GameManager.DrawACard(player, card);
                                    }
                                }
                            }
                        }
                        else
                            foreach (Dictionary<string, string> dict in GameManager.items[i + 1].hand)
                            {
                                if (!Contains(GameManager.items[i].hand, dict))
                                {
                                    card = GameManager.DictionaryToCardObject(dict);
                                    break;
                                }
                            }
                    }
                    else
                    {
                        card = GameManager.DictionaryToCardObject(GameManager.items[i + 1].pile);
                    }
                }
                else
                {
                    if (add)
                    {
                        if (GameManager.items[i + 1].others[turn2] - GameManager.items[i].others[turn1] > 1)
                        {
                            for (int x = 0; x < GameManager.items[i + 1].others[turn2] - GameManager.items[i].others[turn1] - 1; x++)
                            {
                                GameManager.DrawACard(player, card);
                            }
                        }
                    }
                }
                GameManager.Turn(player, pile, add, card);
                GameManager.current_turn = GameManager.current_turn + 1;
            }
            else
            {
                int player = GameManager.items[i].turn - GameManager.ourID;
                if (player < 0)
                {
                    player += 4;
                }
                label2.Text = GameManager.current_turn.ToString();
                try
                {
                    GameManager.current = GameManager.FindCardInHand(player, GameManager.DictionaryToCardObject(GameManager.items[i].hand[0])).cardPicture;
                }
                catch { }
                GameManager.RemoveACard(player, GameManager.DictionaryToCardObject(GameManager.items[i].hand[0]));
                GameManager.gameOver = true;
                ShowWinnerMessage(player, i);
            }
        }
    }
}
