﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Taki
{
    public enum CardColor {
        Red = 1,
        Blue = 2,
        Green = 3,
        Yellow = 4,
        NoColor = 5
    }

    public enum CardType {
        One = 1,
        Two = 2,
        Three = 3,
        Four = 4,
        Five = 5,
        Six = 6,
        Seven = 7,
        Eight = 8,
        Nine = 9,
        DrawCards = 10,
        Reverse = 11,
        SkipTurn = 12,
        ChangeColor = 13,
        Taki = 14,
        Plus = 15,
        Back = 16
    }


    public class Card
    {
        public readonly CardColor cardColor;
        public readonly CardType cardType;
        public readonly Image image;

        public Card(CardColor color, CardType type, Image image)
        {
            cardColor = color;
            cardType = type;
            this.image = image;
        }
    }
}
