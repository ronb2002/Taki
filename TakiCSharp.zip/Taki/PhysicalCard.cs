﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Taki
{   // Card Object (has a picture, color, and position)
    public class PhysicalCard
    {
        public readonly Card card;

        public PictureBox cardPicture;

        public PhysicalCard(CardColor color, CardType type, Image image)
        {
            card = new Card(color, type, image);
            cardPicture = new PictureBox
            {
                Image = image,
                SizeMode = PictureBoxSizeMode.StretchImage,
                Size = new Size(103, 146), //size y=x*1.4
                Visible = true
            };
            GameManager.GameForm.Controls.Add(cardPicture);
        }

        public PhysicalCard(Card card, int x, int y)
        {
            this.card = card;
            cardPicture = new PictureBox
            {
                Image = card.image,
                SizeMode = PictureBoxSizeMode.StretchImage,
                Size = new Size(103, 146), //size y=x*1.4
                Location = new Point(x, y),
                Visible = true
            };
            GameManager.GameForm.Controls.Add(cardPicture);

        }
    }
}
