﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace Taki
{
    public class GameManager
    {
        public static Form GameForm { get; set; }

        public static List<Card> gameCards = new List<Card>();

        public static Stack<Card> deck = new Stack<Card>();

        public static List<PhysicalCard>[] playerHands = new List<PhysicalCard>[4];

        public static PictureBox current;

        public static int ourID { get; set; }

        public static int current_turn = 0;

        public static List<JSONObject> items = new List<JSONObject>();

        public static bool gameOver = false;

        public static bool gameStarted = false;

        public static void CreateCards() // Creates the needed cards using Resources
        {
            gameCards.Add(new Card(CardColor.Blue, CardType.One, Properties.Resources.b1));
            gameCards.Add(new Card(CardColor.Blue, CardType.Two, Properties.Resources.b2));
            gameCards.Add(new Card(CardColor.Blue, CardType.Three, Properties.Resources.b3));
            gameCards.Add(new Card(CardColor.Blue, CardType.Four, Properties.Resources.b4));
            gameCards.Add(new Card(CardColor.Blue, CardType.Five, Properties.Resources.b5));
            gameCards.Add(new Card(CardColor.Blue, CardType.Six, Properties.Resources.b6));
            gameCards.Add(new Card(CardColor.Blue, CardType.Seven, Properties.Resources.b7));
            gameCards.Add(new Card(CardColor.Blue, CardType.Eight, Properties.Resources.b8));
            gameCards.Add(new Card(CardColor.Blue, CardType.Nine, Properties.Resources.b9));
            gameCards.Add(new Card(CardColor.Blue, CardType.DrawCards, Properties.Resources.b_draw));
            gameCards.Add(new Card(CardColor.Blue, CardType.Reverse, Properties.Resources.b_reverse));
            gameCards.Add(new Card(CardColor.Blue, CardType.SkipTurn, Properties.Resources.b_skip));
            gameCards.Add(new Card(CardColor.Blue, CardType.Taki, Properties.Resources.b_taki));
            gameCards.Add(new Card(CardColor.Blue, CardType.Plus, Properties.Resources.b_plus));

            gameCards.Add(new Card(CardColor.Green, CardType.One, Properties.Resources.g1));
            gameCards.Add(new Card(CardColor.Green, CardType.Two, Properties.Resources.g2));
            gameCards.Add(new Card(CardColor.Green, CardType.Three, Properties.Resources.g3));
            gameCards.Add(new Card(CardColor.Green, CardType.Four, Properties.Resources.g4));
            gameCards.Add(new Card(CardColor.Green, CardType.Five, Properties.Resources.g5));
            gameCards.Add(new Card(CardColor.Green, CardType.Six, Properties.Resources.g6));
            gameCards.Add(new Card(CardColor.Green, CardType.Seven, Properties.Resources.g7));
            gameCards.Add(new Card(CardColor.Green, CardType.Eight, Properties.Resources.g8));
            gameCards.Add(new Card(CardColor.Green, CardType.Nine, Properties.Resources.g9));
            gameCards.Add(new Card(CardColor.Green, CardType.DrawCards, Properties.Resources.g_draw));
            gameCards.Add(new Card(CardColor.Green, CardType.Reverse, Properties.Resources.g_reverse));
            gameCards.Add(new Card(CardColor.Green, CardType.SkipTurn, Properties.Resources.g_skip));
            gameCards.Add(new Card(CardColor.Green, CardType.Taki, Properties.Resources.g_taki));
            gameCards.Add(new Card(CardColor.Green, CardType.Plus, Properties.Resources.g_plus));

            gameCards.Add(new Card(CardColor.Red, CardType.One, Properties.Resources.r1));
            gameCards.Add(new Card(CardColor.Red, CardType.Two, Properties.Resources.r2));
            gameCards.Add(new Card(CardColor.Red, CardType.Three, Properties.Resources.r3));
            gameCards.Add(new Card(CardColor.Red, CardType.Four, Properties.Resources.r4));
            gameCards.Add(new Card(CardColor.Red, CardType.Five, Properties.Resources.r5));
            gameCards.Add(new Card(CardColor.Red, CardType.Six, Properties.Resources.r6));
            gameCards.Add(new Card(CardColor.Red, CardType.Seven, Properties.Resources.r7));
            gameCards.Add(new Card(CardColor.Red, CardType.Eight, Properties.Resources.r8));
            gameCards.Add(new Card(CardColor.Red, CardType.Nine, Properties.Resources.r9));
            gameCards.Add(new Card(CardColor.Red, CardType.DrawCards, Properties.Resources.r_draw));
            gameCards.Add(new Card(CardColor.Red, CardType.Reverse, Properties.Resources.r_reverse));
            gameCards.Add(new Card(CardColor.Red, CardType.SkipTurn, Properties.Resources.r_skip));
            gameCards.Add(new Card(CardColor.Red, CardType.Taki, Properties.Resources.r_taki));
            gameCards.Add(new Card(CardColor.Red, CardType.Plus, Properties.Resources.r_plus));

            gameCards.Add(new Card(CardColor.Yellow, CardType.One, Properties.Resources.y1));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Two, Properties.Resources.y2));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Three, Properties.Resources.y3));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Four, Properties.Resources.y4));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Five, Properties.Resources.y5));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Six, Properties.Resources.y6));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Seven, Properties.Resources.y7));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Eight, Properties.Resources.y8));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Nine, Properties.Resources.y9));
            gameCards.Add(new Card(CardColor.Yellow, CardType.DrawCards, Properties.Resources.y_draw));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Reverse, Properties.Resources.y_reverse));
            gameCards.Add(new Card(CardColor.Yellow, CardType.SkipTurn, Properties.Resources.y_skip));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Taki, Properties.Resources.y_taki));
            gameCards.Add(new Card(CardColor.Yellow, CardType.Plus, Properties.Resources.y_plus));

            gameCards.Add(new Card(CardColor.NoColor, CardType.ChangeColor, Properties.Resources.changeColor));
            gameCards.Add(new Card(CardColor.NoColor, CardType.Back, Properties.Resources.back));
            gameCards.Add(new Card(CardColor.NoColor, CardType.Taki, Properties.Resources.n_taki));
        }

        public static Card FindCard(CardColor color, CardType type) // Finds the card needed
        {
            foreach(Card card in gameCards)
            {
                if (card.cardColor == color && card.cardType == type)
                {
                    return card;
                }
            }
            return null;
        }

        public static void CreateStartingBoard(Card[] mainPlayerHand) // Creates starting board with cards
        {
            playerHands[0] = new List<PhysicalCard>();
            playerHands[0].Add(new PhysicalCard(mainPlayerHand[0], 257, 478));
            playerHands[0].Add(new PhysicalCard(mainPlayerHand[1], 291, 478));
            playerHands[0].Add(new PhysicalCard(mainPlayerHand[2], 327, 478));
            playerHands[0].Add(new PhysicalCard(mainPlayerHand[3], 363, 478));
            playerHands[0].Add(new PhysicalCard(mainPlayerHand[4], 409, 478));
            playerHands[0].Add(new PhysicalCard(mainPlayerHand[5], 455, 478));
            playerHands[0].Add(new PhysicalCard(mainPlayerHand[6], 471, 478));
            playerHands[0].Add(new PhysicalCard(mainPlayerHand[7], 507, 478));

            Card back = FindCard(CardColor.NoColor, CardType.Back);
            playerHands[1] = new List<PhysicalCard>();
            playerHands[1].Add(new PhysicalCard(back, 12, 197));
            playerHands[1].Add(new PhysicalCard(back, 12, 213));
            playerHands[1].Add(new PhysicalCard(back, 12, 229));
            playerHands[1].Add(new PhysicalCard(back, 12, 245));
            playerHands[1].Add(new PhysicalCard(back, 12, 261));
            playerHands[1].Add(new PhysicalCard(back, 12, 277));
            playerHands[1].Add(new PhysicalCard(back, 12, 293));
            playerHands[1].Add(new PhysicalCard(back, 12, 309));

            playerHands[2] = new List<PhysicalCard>();
            playerHands[2].Add(new PhysicalCard(back, 305, 12));
            playerHands[2].Add(new PhysicalCard(back, 341, 12));
            playerHands[2].Add(new PhysicalCard(back, 377, 12));
            playerHands[2].Add(new PhysicalCard(back, 413, 12));
            playerHands[2].Add(new PhysicalCard(back, 459, 12));
            playerHands[2].Add(new PhysicalCard(back, 505, 12));
            playerHands[2].Add(new PhysicalCard(back, 521, 12));
            playerHands[2].Add(new PhysicalCard(back, 557, 12));

            playerHands[3] = new List<PhysicalCard>();
            playerHands[3].Add(new PhysicalCard(back, 732, 197));
            playerHands[3].Add(new PhysicalCard(back, 732, 213));
            playerHands[3].Add(new PhysicalCard(back, 732, 229));
            playerHands[3].Add(new PhysicalCard(back, 732, 245));
            playerHands[3].Add(new PhysicalCard(back, 732, 261));
            playerHands[3].Add(new PhysicalCard(back, 732, 277));
            playerHands[3].Add(new PhysicalCard(back, 732, 293));
            playerHands[3].Add(new PhysicalCard(back, 732, 309));
           

            current = new PictureBox {
                Image = Properties.Resources.back,
                SizeMode = PictureBoxSizeMode.StretchImage,
                Size = new Size(103, 146), //size y=x*1.4
                Location = new Point(360, 233),
                Visible = true
            };

            GameForm.Controls.Add(current);

            for (int i = 0; i < playerHands.Length; i++)
            {
                foreach(PhysicalCard card in playerHands[i])
                {
                    GameForm.Controls.Add(card.cardPicture);
                }
            }
        } 

        public static PhysicalCard FindCardInHand(int player, Card card) // Finds the card the player put
        {
            foreach (PhysicalCard physicalCard in playerHands[player])
            {
                if (physicalCard.card == card)
                    return physicalCard;
            }
            return null;
        }

        public static void Turn(int player, Card pile, bool add, Card card) // Draws or removes a card from hand
        {
            current.Image = pile.image;
            if (add)
            {
                DrawACard(player, card);
            }
            else
            {
                RemoveACard(player, card);
            }
        }

        public static void RemoveACard(int player, Card card)// Removes card from hand
        {
            if (player != 0)
            {
                GameForm.Controls.Remove(playerHands[player][playerHands[player].Count-1].cardPicture);
                playerHands[player].RemoveRange(playerHands[player].Count-1, 1);
                return;
            }
            int index = playerHands[player].IndexOf(FindCardInHand(player, card));
            if (index == -1)
                return;
            GameForm.Controls.Remove(playerHands[player][index].cardPicture);
            if (index == 0)
            {
                playerHands[player].RemoveRange(0, 1);
                foreach (PhysicalCard physicalCard in playerHands[player])
                {
                    physicalCard.cardPicture.Location = new Point(physicalCard.cardPicture.Location.X - 36, physicalCard.cardPicture.Location.Y);
                }
            }
            else if (index == playerHands[player].Count - 1)
            {
                playerHands[player].RemoveRange(playerHands[player].Count - 1, 1);
            }
            else
            {
                foreach (PhysicalCard physicalCard in playerHands[player].GetRange(index+1, playerHands[player].Count - index - 1))
                {
                    physicalCard.cardPicture.Location = new Point(physicalCard.cardPicture.Location.X - 26, physicalCard.cardPicture.Location.Y);
                }
                playerHands[player].RemoveRange(index, 1);
            }
        }

        public static void DrawACard(int player, Card card) // Adds a card to the player's hand
        {
            if (player == 0 || player == 2)
            {
                playerHands[player].Add(new PhysicalCard(card, playerHands[player][playerHands[player].Count - 1].cardPicture.Location.X + 36,
                    playerHands[player][0].cardPicture.Location.Y));
            }
            else
            {
                playerHands[player].Add(new PhysicalCard(card, playerHands[player][0].cardPicture.Location.X,
                    playerHands[player][playerHands[player].Count - 1].cardPicture.Location.Y + 16));
            }
            GameForm.Controls.Add(playerHands[player][playerHands[player].Count - 1].cardPicture);
        }

        public static Card DictionaryToCardObject(Dictionary<string,string> dict) // Translates json to card object
        {
            CardColor color;
            CardType type;

            switch (dict["color"]) {
                case "green":
                    color = CardColor.Green;
                    break;
                case "blue":
                    color = CardColor.Blue;
                    break;
                case "red":
                    color = CardColor.Red;
                    break;
                case "yellow":
                    color = CardColor.Yellow;
                    break;
                default:
                    color = CardColor.NoColor;
                    break;
            }

            switch (dict["value"]) {
                case "1":
                    type = CardType.One;
                    break;
                case "2":
                    type = CardType.Two;
                    break;
                case "3":
                    type = CardType.Three;
                    break;
                case "4":
                    type = CardType.Four;
                    break;
                case "5":
                    type = CardType.Five;
                    break;
                case "6":
                    type = CardType.Six;
                    break;
                case "7":
                    type = CardType.Seven;
                    break;
                case "8":
                    type = CardType.Eight;
                    break;
                case "9":
                    type = CardType.Nine;
                    break;
                case "+":
                    type = CardType.Plus;
                    break;
                case "+2":
                    type = CardType.DrawCards;
                    break;
                case "STOP":
                    type = CardType.SkipTurn;
                    break;
                case "CHDIR":
                    type = CardType.Reverse;
                    break;
                case "CHCOL":
                    type = CardType.ChangeColor;
                    break;
                case "TAKI":
                    type = CardType.Taki;
                    break;
                default:
                    type = CardType.Back;
                    break;
            }
            return FindCard(color, type);
        }

        public static JSONObject JsonTextToObject(string json) // Translates json to Dic objects
        {
            string temp = json;
            JSONObject jsonObject = new JSONObject();
            jsonObject.turn = int.Parse(temp.Substring(temp.IndexOf("turn")+7,1));
            temp = temp.Substring(temp.IndexOf("pile_color")+14);
            jsonObject.pile_color = temp.Substring(0, temp.IndexOf("\""));
            temp = temp.Substring(temp.IndexOf("\""));
            string hand = temp.Substring(temp.IndexOf("[")+1, temp.IndexOf("]") - temp.IndexOf("[") - 1);
            Dictionary<string, string> dict = new Dictionary<string, string>();
            string value;
            while (hand.Contains("{"))
            {
                dict = new Dictionary<string, string>();
                value = hand.Substring(hand.IndexOf("\"color\": \"") + 10, hand.IndexOf("\", \"value\": \"") - hand.IndexOf("\"color\": \"") - 10);
                dict.Add("color", value);
                value = hand.Substring(hand.IndexOf("\", \"value\": \"") + 13, hand.IndexOf("\"}") - hand.IndexOf("\", \"value\": \"") - 13);
                dict.Add("value", value);
                hand = hand.Substring(hand.IndexOf("}")+1);
                DictionaryToCardObject(dict);
                jsonObject.hand.Add(dict);
            }
            temp = temp.Substring(temp.IndexOf("players") + 11);
            string players = temp.Substring(0, temp.IndexOf("]"));
            while (players.Length != 0)
            {
                jsonObject.players.Add(int.Parse(players.Substring(0, 1)));
                if (players.Contains(","))
                    players = players.Substring(3);
                else
                    players = "";
            }

            temp = temp.Substring(temp.IndexOf("winners") + 11);
            string  winners = temp.Substring(0, temp.IndexOf("]") - 2);
            while (winners.Length != 0)
            {
                
                if (winners.Contains(","))
                {
                    jsonObject.winners.Add(winners.Substring(0,winners.IndexOf(",")));
                    winners = winners.Substring(winners.IndexOf(",")+2);
                }
                else
                {
                    jsonObject.winners.Add(winners.Substring(0));
                    winners = "";
                }  
            }
            temp = temp.Substring(temp.IndexOf("pile") + 8);
            dict = new Dictionary<string, string>();
            value = temp.Substring(temp.IndexOf("\"color\": \"") + 10, temp.IndexOf("\", \"value\": \"") - temp.IndexOf("\"color\": \"") - 10);
            dict.Add("color", value);
            value = temp.Substring(temp.IndexOf("\", \"value\": \"") + 13, temp.IndexOf("\"}") - temp.IndexOf("\", \"value\": \"") - 13);
            dict.Add("value", value);
            jsonObject.pile = dict;

            jsonObject.turn_dir = int.Parse(temp.Substring(temp.IndexOf("turn_dir")+11, temp.IndexOf(", \"others") - temp.IndexOf("turn_dir") - 11));

            temp = temp.Substring(temp.IndexOf("others") + 10);
            string others = temp.Substring(0, temp.IndexOf("]"));
            while (others.Length != 0)
            {
                if (others.Contains(","))
                {
                    jsonObject.others.Add(int.Parse(others.Substring(0, others.IndexOf(","))));
                    others = others.Substring(others.IndexOf(",") + 2);
                }
                else
                {
                    jsonObject.others.Add(int.Parse(others.Substring(0)));
                    others = "";
                }
            }

            return jsonObject;
        }

        private static List<string> SplitByLines(string str)
        {
            string temp = str;
            List<string> list = new List<string>();
            if (str.Contains("\n"))
            {
                do
                {
                    list.Add(temp.Substring(0, temp.IndexOf("\n")));
                    temp = temp.Substring(temp.IndexOf("\n")+1);
                } while (temp.Contains("\n"));
                if (temp.Length != 0)
                    list.Add(temp);
            }
            else
                list.Add(temp);
            return list;
        }

        private static List<JSONObject> ReadFromJsonFile() // Reads the info from the json file
        {
            //List<JSONObject> items = new List<JSONObject>();
            using (StreamReader r = new StreamReader("C:/Users/ron4r/PycharmProjects/taki_backend/info.json"))
            {
                string json = r.ReadToEnd();
                //Dictionary<string, int> id = JsonConvert.DeserializeObject<Dictionary<string, int>>(json.Substring(0, json.IndexOf("\n") - 1));
                //ourID = id["our_id"];
                List<string> jsons = SplitByLines(json);
                ourID = int.Parse(jsons[0].Substring(jsons[0].IndexOf("id")+5,1));
                //items = JsonConvert.DeserializeObject<List<JSONObject>>(json);
                for (int i = 1; i < jsons.Count; i++)
                {
                    items.Add(JsonTextToObject(jsons[i]));
                }
            }
            return items;
        }

        private static List<Card> TranslateHandFromJson(List<JSONObject> items) // Translates json to list of cards (hand)
        {
            List<Card> hand = new List<Card>();

            foreach (Dictionary<string, string> dict in items[0].hand)
            {
                hand.Add(DictionaryToCardObject(dict));
            }

            return hand;
        }

        public static void StartGame() // Starts game when the start button is pressed
        {
            gameStarted = true;

            List<JSONObject> items = ReadFromJsonFile();

            List<Card> hand = TranslateHandFromJson(items);

            CreateStartingBoard(hand.ToArray());

            current.Image = DictionaryToCardObject(items[0].pile).image;
        }
    }
}
